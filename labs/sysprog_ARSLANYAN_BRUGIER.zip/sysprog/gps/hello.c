#include <stdio.h>

int main()
{
	printf("Hello word");
	return 0;
}
