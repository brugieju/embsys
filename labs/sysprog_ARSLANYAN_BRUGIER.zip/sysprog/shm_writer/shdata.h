#ifndef SHDATA_H
#define SHDATA_H

struct SHDATA
{
    float latitude;
    float longitude;
    int time;
};

#endif // SHDATA_H
